package com.cslg;

public class Car {
	private String color;
	private boolean airConditioner;
	
	
	
	public Car(String color, boolean airConditioner) {
		super();
		this.color = color;
		this.airConditioner = airConditioner;
	}
	
	
	public Car() {
		super();
		// TODO Auto-generated constructor stub
	}


	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	public boolean isAirConditioner() {
		return airConditioner;
	}
	public void setAirConditioner(boolean airConditioner) {
		this.airConditioner = airConditioner;
	}
	

}
