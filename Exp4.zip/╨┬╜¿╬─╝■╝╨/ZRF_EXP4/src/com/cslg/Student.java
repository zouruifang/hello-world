package com.cslg;

public class Student {
	private String name;
    private String password;
    private String cheakpassword;
    private String sex;
    private String [] like;
    
	public Student() {
		super();
	}
	public Student(String name, String password, String cheakpassword, String sex, String[] like) {
		super();
		this.name = name;
		this.password = password;
		this.cheakpassword = cheakpassword;
		this.sex = sex;
		this.like = like;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getCheakpassword() {
		return cheakpassword;
	}
	public void setCheakpassword(String cheakpassword) {
		this.cheakpassword = cheakpassword;
	}
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public String[] getLike() {
		return like;
	}
	public void setLike(String[] like) {
		this.like = like;
	}
    
}
